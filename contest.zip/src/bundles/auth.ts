export { default as AuthCode } from '../components/auth/AuthCode';
export { default as AuthPassword } from '../components/auth/AuthPassword';
export { default as AuthRegister } from '../components/auth/AuthRegister';
