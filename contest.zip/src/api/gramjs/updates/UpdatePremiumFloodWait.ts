export default class LocalUpdatePremiumFloodWait {
  constructor(public isUpload: boolean) {}
}
